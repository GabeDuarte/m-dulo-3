const nome = 'Calculadora versão 1.0';

function soma(a, b) {
    return a + b;
}

function sub(a, b) {
    return a - b;
}

function mult(a, b) {
    return a * b;
}

function div(a, b) {
    return a / b;
}

module.exports = {
    soma,
    sub,
    mult,
    div,
    nome,
};
