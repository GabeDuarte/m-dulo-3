const mostrarSite = true;
const site = 'https://blueedtech.com.br/';

console.log('Hello Node.js!');
console.log('Meu nome é Gustavo!');
console.log('E eu estou aprendendo Node.js com a Blue.');

if (mostrarSite) { // Se mostrar site
    console.log(site); // Print o site
}
